Ping CLI - Written by Dylan Halland, for Cloudflare Systems Internship (April 2019)

Notes:
- Run the command "make" to compile the necessary source code
- Once compiled, run the program using root privileges
- For instance: sudo ./ping [host-name/ip-address]
